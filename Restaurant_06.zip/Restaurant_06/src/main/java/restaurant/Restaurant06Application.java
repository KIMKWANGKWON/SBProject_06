package restaurant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Restaurant06Application {

	public static void main(String[] args) {
		SpringApplication.run(Restaurant06Application.class, args);
	}

}
