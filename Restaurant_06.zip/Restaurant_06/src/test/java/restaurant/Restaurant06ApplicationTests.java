package restaurant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Restaurant06ApplicationTests {

	@Test
	void contextLoads() {
	}

}
